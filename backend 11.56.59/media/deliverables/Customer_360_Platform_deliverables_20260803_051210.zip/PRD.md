# Product Requirements Document
## Customer 360 Platform

**Company:** Acme Corp

## Product Overview
Unify customer data across sales, support and marketing.

## Goals
Deliver a single customer view to drive retention.

## Constraints
- Expected timeline: 8 weeks
- Current maturity level: 1
