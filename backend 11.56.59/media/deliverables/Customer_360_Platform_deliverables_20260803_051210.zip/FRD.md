# Functional Requirements Document
## Customer 360 Platform

**Company:** Acme Corp
**Current Level:** 1
**Readiness:** 0%

## Functional Scope
Functional requirements are derived from the uploaded level documents and
the business objectives described below.

## Business Objectives
Deliver a single customer view to drive retention.

## Team
John Smith, Arthur Pendragon
