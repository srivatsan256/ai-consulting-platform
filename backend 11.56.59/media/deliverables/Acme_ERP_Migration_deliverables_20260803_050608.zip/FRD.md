# Functional Requirements Document
## Acme ERP Migration

**Company:** Acme Corp
**Current Level:** 1
**Readiness:** 0%

## Functional Scope
Functional requirements are derived from the uploaded level documents and
the business objectives described below.

## Business Objectives
Migrate ERP to cloud with 99.9% uptime and 20% cost savings.

## Team
John Smith, Robert Kiyosaki
